import UIKit

//Variables & Constants

//snake_case
//camelCase

// PART 1

//String

var userName = "James"
userName.append("o")
userName.lowercased()
userName.uppercased()

var userSurname = "Hetfield"

userName = "Lars"

//integer & double & float

//integer
let userAge = 50
let myNumber = 4
userAge / myNumber


//double
let userAgeD = 50.0
var myNumberD = 4.0
userAgeD / myNumberD

//boolean

var myBoolean = false
myBoolean = true

// ------- PART 2 --------

let myString : String = "50"
let anotherNumber : Int = 10

let stringNumber : String = String(20)

//define

let myVariable : String

//initialization

myVariable = "Test"
let myUpperVariable = myVariable.uppercased()
print(myUpperVariable)
print(myVariable)







